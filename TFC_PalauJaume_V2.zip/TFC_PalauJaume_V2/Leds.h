
#ifndef Leds
#define Leds

#define LED_W 4
#define LED_R 19
#define LED_Y 21
#define LED_G 23
//#define potaLDR 32
#define y 35
#define x 32

#endif

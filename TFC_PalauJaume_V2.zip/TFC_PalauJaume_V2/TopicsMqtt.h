#ifndef TopicsMqtt
#define TopicsMqtt
#define  TOPIC_FANAL "/fanal"
#define SEMAFOR_VERMELL "/Vermell_esp"
#define SEMAFOR_GROC "/Groc_esp"
#define SEMAFOR_VERD "/Verd_esp"
#define TOPIC_LDR "/ldr"
#define TOPIC_STOP "/stop"
#define TOPIC_ENDEVANT "/forward"
#endif 
